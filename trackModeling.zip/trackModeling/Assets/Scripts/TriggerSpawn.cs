﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/*
A script of this class must be attached to EVERY segment prefab unless you rework the entire system.
 */
public class TriggerSpawn : MonoBehaviour {

	private float delay = 10f; //delay (in seconds) before a segment deletes itself from the world

	void Start () {
		
	}
	
	void Update () {
		
	}

	/*
	When the car(the only "other" that can move through trigger zones) exits a trigger zone, this method will:
		call the spawnNext function from SpawnRoad
		delete the segment that was run over after a delay
	The so called "trigger zone" is a box collider on each road segment set with the "Is Trigger" marker.
	Its component values are copy-pasteable, and this must be done in the case of any newly created segments.
	 */
	void OnTriggerExit(Collider other)
	{
		SpawnRoad.Instance.spawnNext(); //spawns a segment at the end of the chain

		StartCoroutine(DeleteSegment()); //begins the coroutine to delete the segment
	}

	/*
	Coroutine to delete a segment.
	Runs in parallel to OnTriggerExit().
	 */
	IEnumerator DeleteSegment()
	{
		yield return new WaitForSeconds(delay); //waits for (delay) seconds
		Destroy(gameObject); //destroys the gameobject this script is attached to
	}
}
