﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpawnRoad : MonoBehaviour {

	/* 
	instance is used here to make sure that there is only one SpawnRoad object at any given time,
	so that all external references to it (such as in TriggerSpawn) will call the right SpawnRoad
	 */
	private static SpawnRoad instance; 
	public static SpawnRoad Instance 
	{
		get
		{
			if(instance == null)
			{
				instance = GameObject.FindObjectOfType<SpawnRoad>();
			}
			return instance;
		}
	}

	public GameObject currentSegment; //most recently constructed segment
	public GameObject previousSegment; //deprecated. initially i thought this would be needed to delete stale segments
	public GameObject nextSegment; //the next segment to be created

	/*
	I'm not sure if this is necessary to be able to connect the unity prefabs to the code.
	In the case that you have more Unity or C# experience, feel free to fix the inefficiencies in my code. */
	public static GameObject straight;
	public static GameObject rightNinety;
	public static GameObject leftNinety;
	public static GameObject swerveRight;
	public static GameObject curve1;
	public static GameObject curve2;
	public static GameObject curve3;
	public static GameObject sshape;
	public static GameObject leftCurve;

	public GameObject[] segments = {straight, rightNinety, leftNinety, swerveRight, curve1, curve2, curve3,
		sshape, leftCurve}; //array of all the different types of segments
		//add or subtract segments from this array to change the pool of random segments
		/*
		segment standards:
		plane
		x-scale of 2
		y-scale of 1
		z-scale varies, must chain several together to create curves 
		The parent of the entire segment is the "start point", an empty gameobject
			in the middle of the starting edge, facing inward
		The first child of the afformentioned parent is the "end point", an empty gameobject
			in the middle of the ending edge, facing outward
		*/ 

	public static readonly int numberOfTypes = 9; //must be changed alongside the array!
	public System.Random rand = new System.Random(); //makes sure the same random number doesn't get chosen several times

	void Start () {
		for(int i = 0; i<3; i++) //initially, 3 segments are created as a buffer
		{
			spawnNext();
		}
	}
	
	void Update () {
		
	}

	public void spawnNext() //spawns a random 
	{
		previousSegment = currentSegment; //deprecated

		int segmentType = rand.Next(0, numberOfTypes); //makes a random index
		nextSegment = segments[segmentType]; //gets a segment using the index, puts it in nextSegment

		currentSegment = (GameObject)Instantiate(nextSegment, currentSegment.transform.GetChild(0).position, currentSegment.transform.GetChild(0).transform.rotation);
		/* The following breaks down what this line does--or is meant to do:
		"currentSegment = (GameObject)"  sets currentSegment to the newly created segment, which is cast as a GameObject
		"Instantiate(nextSegment "  Instantiates whatever type of segment was loaded into nextSegment
		"currentSegment.transform.GetChild(0).position"  creates the new segment at the first child (i.e. the endpoint) of the currentSegment
		"currentSegement.transform.GetChild(0).transform.rotation"  rotates the new segment's starting point (and thus the entire segment) to match the endpoint of the current segment
		*/
	}

}
